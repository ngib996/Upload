<?php
// src/JCV/UserBundle/Entity/User.php

namespace JCV\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @ORM\Table(uniqueConstraints={@ORM\UniqueConstraint(name="user_unique",
 *                                                  columns={"first_name","last_name"})},
 *              indexes={@ORM\Index(name="search_idx",
 *                               columns={"first_name","last_name"})}
 * )
 * @ORM\Entity(repositoryClass="JCV\UserBundle\Entity\UserRepository")
 * @ORM\HasLifecycleCallbacks
 */
class User implements UserInterface {
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /** @ORM\Column(type="string", name="first_name", nullable=false) */
    private $firstName;

    /** @ORM\Column(type="string", name="last_name", nullable=false) */
    private $lastName;

    /** @ORM\Column(type="string", nullable=false) */
    private $gender;

    /** @ORM\Column(type="string", name="name_prefix", nullable=false) */
    private $namePrefix;

    /**
     * @ORM\Column(name="username", type="string", length=255, unique=true)
     */
    private $username;

    /**
     * @ORM\Column(name="password", type="string", length=255)
     */
    private $password;

    /**
     * @ORM\Column(name="salt", type="string", length=255)
     */
    private $salt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime")
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated", type="datetime")
     */
    private $updated;

    const GENDER_MALE = 0;
    const GENDER_FEMALE = 1;

    const GENDER_MALE_DISPLAY_VALUE = "Mr.";
    const GENDER_FEMALE_DISPLAY_VALUE = "Mrs.";

    /**
     * @ORM\OneToOne(targetEntity="JCV\UserBundle\Entity\Image", cascade={"persist","remove"})
     */
    private $image;

    /**
    * @ORM\OneToOne(targetEntity="JCV\UserBundle\Entity\ContactData", cascade={"persist","remove"})
    */

    private $contactData;

     /**
     * @ORM\OneToOne(targetEntity="JCV\UserBundle\Entity\UserInfo", inversedBy="user", cascade={"persist","remove"})
     */
    private $userInfo;

    /**
    * @ORM\ManyToMany(targetEntity="JCV\UserBundle\Entity\Role")
    * */
    private $roles;

    /**
     * @ORM\OneToOne(targetEntity="JCV\UserBundle\Entity\User")
     * @ORM\JoinColumn(name="live_partner_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $lifePartner;

    /**
    * @ORM\ManyToMany(targetEntity="JCV\UserBundle\Entity\User")
    * @ORM\JoinTable(name="friends",
    *       joinColumns={@ORM\JoinColumn(name="user_id",
    *                       referencedColumnName="id")},
    *       inverseJoinColumns={@ORM\JoinColumn(name="friend_user_id",referencedColumnName="id")}
    * )
    **/
    private $myFriends;


    public function __construct()
    {
      $this->setCreated(new \DateTime());
      $this->setUpdated(new \DateTime());
      $this->roles = new ArrayCollection();
      $this->myFriends = new ArrayCollection();
    }

    /**
    * @ORM\PreUpdate
    */
    public function setUpdatedValue() {
        $this->setUpdated(new \DateTime());
    }

    public function __toString() {
        return $this->getUserName();
    }

    public function assembleDisplayName() {
        $displayName = '';

        if ($this->gender == self::GENDER_MALE) {
            $displayName .= self::GENDER_MALE_DISPLAY_VALUE;
        } elseif ($this->gender == self::GENDER_FEMALE) {
            $displayName .= self::GENDER_FEMALE_DISPLAY_VALUE;
        }

        if ($this->namePrefix) {
            $displayName .= ' ' . $this->namePrefix;
        }

        $displayName .= ' ' . $this->firstName . ' ' . $this->lastName;

        return $displayName;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     * @return User
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;

        return $this;
    }

    /**
     * Get firstName
     *
     * @return string
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     * @return User
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set gender
     *
     * @param string $gender
     * @return User
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return string
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set namePrefix
     *
     * @param string $namePrefix
     * @return User
     */
    public function setNamePrefix($namePrefix)
    {
        $this->namePrefix = $namePrefix;

        return $this;
    }

    /**
     * Get namePrefix
     *
     * @return string
     */
    public function getNamePrefix()
    {
        return $this->namePrefix;
    }

    /**
     * Set created
     *
     * @param \DateTime $created
     * @return User
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set updated
     *
     * @param \DateTime $updated
     * @return User
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * Get updated
     *
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * Set contactData
     *
     * @param \JCV\UserBundle\Entity\ContactData $contactData
     * @return User
     */
    public function setContactData(\JCV\UserBundle\Entity\ContactData $contactData = null)
    {
        $this->contactData = $contactData;

        return $this;
    }

    /**
     * Get contactData
     *
     * @return \JCV\UserBundle\Entity\ContactData
     */
    public function getContactData()
    {
        return $this->contactData;
    }

    /**
     * Set userInfo
     *
     * @param \JCV\UserBundle\Entity\UserInfo $userInfo
     * @return User
     */
    public function setUserInfo(\JCV\UserBundle\Entity\UserInfo $userInfo = null)
    {
        $this->userInfo = $userInfo;

        return $this;
    }

    /**
     * Get userInfo
     *
     * @return \JCV\UserBundle\Entity\UserInfo
     */
    public function getUserInfo()
    {
        return $this->userInfo;
    }



    /**
     * Set lifePartner
     *
     * @param \JCV\UserBundle\Entity\User $lifePartner
     * @return User
     */
    public function setLifePartner(\JCV\UserBundle\Entity\User $lifePartner = null)
    {
        $this->lifePartner = $lifePartner;

        return $this;
    }

    /**
     * Get lifePartner
     *
     * @return \JCV\UserBundle\Entity\User
     */
    public function getLifePartner()
    {
        return $this->lifePartner;
    }

    /**
     * Add myFriends
     *
     * @param \JCV\UserBundle\Entity\User $myFriends
     * @return User
     */
    public function addMyFriend(\JCV\UserBundle\Entity\User $myFriends)
    {
        $this->myFriends[] = $myFriends;

        return $this;
    }

    /**
     * Remove myFriends
     *
     * @param \JCV\UserBundle\Entity\User $myFriends
     */
    public function removeMyFriend(\JCV\UserBundle\Entity\User $myFriends)
    {
        $this->myFriends->removeElement($myFriends);
    }

    /**
     * Get myFriends
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getMyFriends()
    {
        return $this->myFriends;
    }

    /**
     * Set image
     *
     * @param \JCV\UserBundle\Entity\Image $image
     * @return User
     */
    public function setImage(\JCV\UserBundle\Entity\Image $image = null)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return \JCV\UserBundle\Entity\Image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set username
     *
     * @param string $username
     * @return User
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set password
     *
     * @param string $password
     * @return User
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set salt
     *
     * @param string $salt
     * @return User
     */
    public function setSalt($salt)
    {
        $this->salt = $salt;

        return $this;
    }

    /**
     * Get salt
     *
     * @return string
     */
    public function getSalt()
    {
        return $this->salt;
    }

    public function eraseCredentials() {

    }
     /**
     * Get roles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getRoles() {

        return $this->roles;
    }

         /**
     * Get rolesAsArray
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getRolesAsArray() {
        $roleArray = array();
        foreach ($this->roles as $role) {
            $roleArray[] = $role->getLabel();
        }
        return $roleArray;

    }


    /**
     * Add roles
     *
     * @param \JCV\UserBundle\Entity\Role $roles
     * @return User
     */
    public function addRole(\JCV\UserBundle\Entity\Role $roles)
    {
        $this->roles[] = $roles;

        return $this;
    }

    /**
     * Remove roles
     *
     * @param \JCV\UserBundle\Entity\Role $roles
     */
    public function removeRole(\JCV\UserBundle\Entity\Role $roles)
    {
        $this->roles->removeElement($roles);
    }
}
