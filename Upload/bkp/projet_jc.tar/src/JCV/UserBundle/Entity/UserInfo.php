<?php
// src/JCV/UserBundle/Entity/UserInfo.php

namespace JCV\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity(repositoryClass="JCV\UserBundle\Entity\UserInfoRepository")
 * @ORM\HasLifecycleCallbacks
 * @ORM\Table(name="user_info")
 */
class UserInfo
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /** @ORM\Column(type="datetime", nullable=true) */
    private $signUpDate;

    /** @ORM\Column(type="datetime", nullable=true) */
    private $signOffDate = null;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime")
     */
    private $created;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated", type="datetime")
     */
    private $updated;

    /**
     * @ORM\OneToOne(targetEntity="JCV\UserBundle\Entity\User", mappedBy="userInfo")
     */
    private $user;

    public function __construct() {
        $this->setCreated(new \DateTime());
        $this->setUpdated(new \DateTime());
        $this->setSignUpDate(new \DateTime());
    }

    /**
     * @ORM\PreUpdate
     */
    public function setUpdatedValue() {
        $this->setUpdated(new \DateTime());
    }

    public function __toString() {
        return $this->getId();
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set signUpDate
     *
     * @param \DateTime $signUpDate
     * @return UserInfo
     */
    public function setSignUpDate($signUpDate)
    {
        $this->signUpDate = $signUpDate;

        return $this;
    }

    /**
     * Get signUpDate
     *
     * @return \DateTime
     */
    public function getSignUpDate()
    {
        return $this->signUpDate;
    }

    /**
     * Set signOffDate
     *
     * @param \DateTime $signOffDate
     * @return UserInfo
     */
    public function setSignOffDate($signOffDate)
    {
        $this->signOffDate = $signOffDate;

        return $this;
    }

    /**
     * Get signOffDate
     *
     * @return \DateTime
     */
    public function getSignOffDate()
    {
        return $this->signOffDate;
    }

    /**
     * Set created
     *
     * @param \DateTime $created
     * @return UserInfo
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set updated
     *
     * @param \DateTime $updated
     * @return UserInfo
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;

        return $this;
    }

    /**
     * Get updated
     *
     * @return \DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * Set user
     *
     * @param \JCV\UserBundle\Entity\User $user
     * @return UserInfo
     */
    public function setUser(\JCV\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \JCV\UserBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
}
