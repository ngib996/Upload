<?php
// srv/JCV/UserBundle/Admin/UserAdmin.php

namespace JCV\UserBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;
class UserAdmin extends Admin {

    // Fields to be shown on create/edit forms
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
        ->add('username', 'text', array('label' => 'Username'))
        ->add('gender', 'text', array('label' => 'Gender'))
        ->add('firstName', 'text', array('label' => 'First Name'))
        ->add('lastName', 'text', array('label' => 'Last Name'))
        ->add('roles', 'entity', array('class' => 'JCV\UserBundle\Entity\Role'))
            ;
    }

    // Fields to be shown on filter forms
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
    $datagridMapper
        ->add('gender')
        ->add('username')
        ->add('firstName')
        ->add('lastName')
        ->add('roles')
        ;
    }

    // Fields to be shown on lists
    protected function configureListFields(ListMapper $listMapper)
    {
    $listMapper
        ->addIdentifier('username')
        ->add('gender')
                ->add('firstName')
        ->add('lastName')
        ->add('roles')
        ;
    }
}