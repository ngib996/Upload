<?php
// src/JCV/UserBundle/Form/Type/UserEditType.php

namespace JCV\UserBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use JCV\UserBundle\Entity\CategoryRepository;

class UserEditType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->remove('userInfo');
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'jcv_bundle_user_edit';
    }

    public function getParent() {
        return new UserType();
    }

}
