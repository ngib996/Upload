<?php

// src/JCV/UserBundle/DataFixtures/ORM/ContactDataFixtures.php

namespace JCV\UserBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use JCV\UserBundle\Entity\ContactData;

class ContactDataFixtures extends AbstractFixture implements OrderedFixtureInterface {

    public function load(ObjectManager $manager) {

        $contactData1 = new ContactData();
        $contactData1->setEmail('jeanchristophe.verhulst@gmail.com');
        $contactData1->setPhone('+32479175304');
        $contactData1->setCreated(new \DateTime());
        $contactData1->setUpdated($contactData1->getCreated());
        $manager->persist($contactData1);

        $contactData2 = new ContactData();
        //$contactData2->setEmail('arnaudverhulstcod@hotmail.com');
        $contactData2->setEmail('jeanchristophe.verhulst@gmail.com');
        $contactData2->setPhone('+32497932768');
        $contactData2->setCreated(new \DateTime());
        $contactData2->setUpdated($contactData2->getCreated());
        $manager->persist($contactData2);

        $contactData3 = new ContactData();
        //$contactData3->setEmail('victoria.verhulst@gmail.com');
        $contactData3->setEmail('jeanchristophe.verhulst@gmail.com');
        $contactData3->setPhone('+32493599603');
        $contactData3->setCreated(new \DateTime());
        $contactData3->setUpdated($contactData3->getCreated());
        $manager->persist($contactData3);

        $contactData4 = new ContactData();
        $contactData4->setEmail('isa.gioia272@gmail.com');
        $contactData4->setPhone('+32494829181');
        $contactData4->setCreated(new \DateTime());
        $contactData4->setUpdated($contactData4->getCreated());
        $manager->persist($contactData4);

        $manager->flush();

        $this->addReference('contact-data-1', $contactData1);
        $this->addReference('contact-data-2', $contactData2);
        $this->addReference('contact-data-3', $contactData3);
        $this->addReference('contact-data-4', $contactData4);
    }

    public function getOrder() {
        return 1;
    }

}
