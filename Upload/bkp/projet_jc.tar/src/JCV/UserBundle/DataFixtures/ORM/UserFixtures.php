<?php

// src/JCV/UserBundle/DataFixtures/ORM/UserFixtures.php

namespace JCV\UserBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use JCV\UserBundle\Entity\User;

class UserFixtures extends AbstractFixture implements OrderedFixtureInterface,  ContainerAwareInterface {

    private $container;

    public function setContainer(ContainerInterface $container = null) {
        $this->container = $container;
    }

    public function load(ObjectManager $manager) {
        // Liste des noms de catégorie à ajouter
        $user1 = new User();
        $user1->setFirstName('Jean-Christophe');
        $user1->setLastName('Verhulst');
        $user1->setGender('male');
        $user1->setNamePrefix('Mr.');
        $user1->setUsername('jcv');
        $user1->setPassword('jcv');
        $user1->setSalt('');
//        $user1->setRoles(array('ROLE_USER'));
        $user1->setCreated(new \DateTime());
        $user1->setUpdated($user1->getCreated());
        $user1->setContactData($manager->merge($this->getReference('contact-data-1')));
        $user1->setUserInfo($manager->merge($this->getReference('user-info-1')));
        $user1->addRole($manager->merge($this->getReference('role-1')));
        $user1->setImage($manager->merge($this->getReference('image-9')));
        $manager->persist($user1);

        $user2 = new User();
        $user2->setFirstName('Arnaud');
        $user2->setLastName('Verhulst');
        $user2->setGender('male');
        $user2->setNamePrefix('Mr.');
        $user2->setUsername('arnaud');
        $user2->setPassword('arnaud');
        $user2->setSalt('');
//        $user2->setRoles(array('ROLE_USER','ROLE_ADMIN'));
        $user2->setCreated(new \DateTime());
        $user2->setUpdated($user2->getCreated());
        $user2->setContactData($manager->merge($this->getReference('contact-data-2')));
        $user2->setUserInfo($manager->merge($this->getReference('user-info-2')));
        $user2->addRole($manager->merge($this->getReference('role-2')));
        $user2->addMyFriend($user1);
        $user2->setImage($manager->merge($this->getReference('image-6')));
        $manager->persist($user2);

        $user3 = new User();
        $user3->setFirstName('Victoria');
        $user3->setLastName('Verhulst');
        $user3->setGender('female');
        $user3->setNamePrefix('Mrs.');
        $user3->setUsername('vic');
        $user3->setPassword('vic');
        $user3->setSalt('');
//        $user3->setRoles(array('ROLE_ADMIN'));
        $user3->setCreated(new \DateTime());
        $user3->setUpdated($user3->getCreated());
        $user3->setContactData($manager->merge($this->getReference('contact-data-3')));
        $user3->setUserInfo($manager->merge($this->getReference('user-info-3')));
        $user3->addRole($manager->merge($this->getReference('role-2')));
        $user3->addMyFriend($user1);
        $user3->addMyFriend($user2);
        $user3->setImage($manager->merge($this->getReference('image-7')));
        $manager->persist($user3);

        $user4 = new User();
        $user4->setFirstName('Isabelle');
        $user4->setLastName('Goffinet');
        $user4->setGender('female');
        $user4->setNamePrefix('Mrs.');
        $user4->setUsername('isa');
        $user4->setPassword('isa');
        $user4->setSalt('');
//        $user4->setRoles(array('ROLE_USER', 'ROLE_ADMIN'));
        $user4->setCreated(new \DateTime());
        $user4->setUpdated($user4->getCreated());
        $user4->setContactData($manager->merge($this->getReference('contact-data-4')));
        $user4->setUserInfo($manager->merge($this->getReference('user-info-4')));
        $user4->addRole($manager->merge($this->getReference('role-2')));
        $user4->addMyFriend($user1);
        $user4->setImage($manager->merge($this->getReference('image-8')));
        $manager->persist($user4);

        $manager->flush();

        $this->addReference('user-1', $user1);
        $this->addReference('user-2', $user2);
        $this->addReference('user-3', $user3);
        $this->addReference('user-4', $user4);

        $em = $this->container->get('doctrine')->getManager();
        $repositoryUser = $em->getRepository('JCVUserBundle:User');

        $jcv=$repositoryUser->findOneBy(array('firstName' => 'Jean-Christophe','lastName'=>'Verhulst'));
        $isa = $repositoryUser->findOneBy(array('firstName' => 'Isabelle', 'lastName' => 'Goffinet'));
        $jcv->setLifePartner($isa);
        $isa->setLifePartner($jcv);

        $manager->flush();
    }

     public function getOrder() {
        return 2;
    }

}
