<?php

// src/JCV/UserBundle/DataFixtures/ORM/UserInfoFixtures.php

namespace JCV\UserBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use JCV\UserBundle\Entity\UserInfo;

class UserInfoFixtures extends AbstractFixture implements OrderedFixtureInterface {

    public function load(ObjectManager $manager) {

        $userInfo1 = new UserInfo();
        $userInfo1->setSignUpDate(new \DateTime());
        $userInfo1->setCreated(new \DateTime());
        $userInfo1->setUpdated($userInfo1->getCreated());
        $manager->persist($userInfo1);

        $userInfo2 = new UserInfo();
        $userInfo2->setSignUpDate(new \DateTime());
        $userInfo2->setCreated(new \DateTime());
        $userInfo2->setUpdated($userInfo2->getCreated());
        $manager->persist($userInfo2);

        $userInfo3 = new UserInfo();
        $userInfo3->setSignUpDate(new \DateTime());
        $userInfo3->setCreated(new \DateTime());
        $userInfo3->setUpdated($userInfo3->getCreated());
        $manager->persist($userInfo3);

        $userInfo4 = new UserInfo();
        $userInfo4->setSignUpDate(new \DateTime());
        $userInfo4->setCreated(new \DateTime());
        $userInfo4->setUpdated($userInfo4->getCreated());
        $manager->persist($userInfo4);

        $manager->flush();

        $this->addReference('user-info-1', $userInfo1);
        $this->addReference('user-info-2', $userInfo2);
        $this->addReference('user-info-3', $userInfo3);
        $this->addReference('user-info-4', $userInfo4);
    }

    public function getOrder() {
        return 1;
    }

}
