<?php

// src/JCV/CoreBundle/Menu/Builder.php

namespace JCV\CoreBundle\Menu;

use Knp\Menu\FactoryInterface;
use Symfony\Component\DependencyInjection\ContainerAware;

class Builder extends ContainerAware {

    public function HomeMenu(FactoryInterface $factory, array $options) {
        $menu = $factory->createItem('root');
        $menu->setChildrenAttribute('class', 'nav pull-left');

        $menu->addChild('Home')->setAttribute('dropdown', true)
                ->setAttribute('icon', 'icon-user');

        $menu['Home']->addChild('Home', array('route' => 'jcv_core_homepage'))->setAttribute('icon', 'fa fa-home fa-fw');
        $menu['Home']->addChild('Contact', array('route' => 'jcv_core_contact'))->setAttribute('icon', 'fa fa-user fa-fw');

        return $menu;
    }

    public function AdminMenu(FactoryInterface $factory, array $options) {
        $menu = $factory->createItem('root');
        $menu->setChildrenAttribute('class', 'nav pull-left');

        $menu->addChild('Admin')->setAttribute('dropdown', true);

        $menu['Admin']->addChild('Users')->setAttribute('icon', 'fa fa-user fa-fw');
        $menu['Admin']->addChild('UserList', array('route' => 'jcv_user_home'))->setAttribute('icon', 'fa fa-newspaper-o fa-fw');
        $menu['Admin']->addChild('UserAdd', array('route' => 'jcv_user_add'))->setAttribute('icon', 'fa fa-user fa-fw')->setAttribute('divider_append', true);

        $menu['Admin']->addChild('Category')->setAttribute('icon', 'fa fa-user fa-fw');
        $menu['Admin']->addChild('CategoryList', array('route' => 'jcv_user_home'))->setAttribute('icon', 'fa fa-newspaper-o fa-fw');
        $menu['Admin']->addChild('CategoryAdd', array('route' => 'jcv_user_add'))->setAttribute('icon', 'fa fa-user fa-fw')->setAttribute('divider_append', true);
        return $menu;
    }

      public function AdvertMenu(FactoryInterface $factory, array $options) {
        $menu = $factory->createItem('root');
        $menu->setChildrenAttribute('class', 'nav pull-left');

        $menu->addChild('Advert')->setAttribute('dropdown', true);



        $menu['Advert']->addChild('List', array('route' => 'jcv_advert_home'))->setAttribute('icon', 'fa fa-newspaper-o fa-fw');
        $menu['Advert']->addChild('Add', array('route' => 'jcv_advert_add'))->setAttribute('icon', 'fa fa-user fa-fw');

        return $menu;
    }

    public function ApplicationMenu(FactoryInterface $factory, array $options) {
        $menu = $factory->createItem('root');
        $menu->setChildrenAttribute('class', 'nav pull-left');

        $menu->addChild('Application')->setAttribute('dropdown', true);



        $menu['Application']->addChild('List', array('route' => 'jcv_application_home'))->setAttribute('icon', 'fa fa-newspaper-o fa-fw');
        $menu['Application']->addChild('Add', array('route' => 'jcv_application_add'))->setAttribute('icon', 'fa fa-user fa-fw');

        return $menu;
    }

    public function LogoutMenu(FactoryInterface $factory, array $options) {
        $menu = $factory->createItem('root');
        $menu->setChildrenAttribute('class', 'nav pull-left');

        $menu->addChild('Logout', array('route' => 'logout'))->setAttribute('icon', 'fa fa-sign-out fa-fw');

        return $menu;
    }

}
