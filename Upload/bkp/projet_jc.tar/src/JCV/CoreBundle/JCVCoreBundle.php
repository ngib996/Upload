<?php

namespace JCV\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JCVCoreBundle extends Bundle
{
}
